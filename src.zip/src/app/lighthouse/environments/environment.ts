// environment.ts
export const environment = {
    production: false,
    // Add other environment-specific settings
  };
  